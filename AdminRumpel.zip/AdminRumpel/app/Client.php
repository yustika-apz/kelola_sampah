<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    protected $table = 'client';
    const CREATED_AT = 'createddate';
    const UPDATED_AT = 'updateddate';
}
