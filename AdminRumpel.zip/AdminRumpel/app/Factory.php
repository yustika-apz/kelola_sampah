<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Factory extends Model
{
    protected $table = 'factory';
    const CREATED_AT = 'createddate';
    const UPDATED_AT = 'updateddate';
}
