<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WasteSalesDet extends Model
{
    protected $table = 'waste_salesdet';
    const CREATED_AT = 'createddate';
    const UPDATED_AT = 'updateddate';
}
