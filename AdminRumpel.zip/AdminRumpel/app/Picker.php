<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Picker extends Model
{
    protected $table = 'picker';
    const CREATED_AT = 'createddate';
    const UPDATED_AT = 'updateddate';
}
