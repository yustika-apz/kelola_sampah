<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalesDet extends Model
{
    protected $table = 'salesdet';
    const CREATED_AT = 'createddate';
    const UPDATED_AT = 'updateddate';
}
