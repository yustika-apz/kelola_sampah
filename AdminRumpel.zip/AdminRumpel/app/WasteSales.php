<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WasteSales extends Model
{
    protected $table = 'waste_sales';
    const CREATED_AT = 'createddate';
    const UPDATED_AT = 'updateddate';
}
