<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lapak extends Model
{
    protected $table = 'lapak';
    const CREATED_AT = 'createddate';
    const UPDATED_AT = 'updateddate';
}
