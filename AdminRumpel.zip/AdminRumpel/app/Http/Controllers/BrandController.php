<?php

namespace App\Http\Controllers;

use App\User;
use App\Brand;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class BrandController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Session::has('log') && Session::get('log') == 0){
            return redirect('/')->with('alert','Anda Belum Login!');
        }

        $data = Brand::all();
        return view('brand',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(!Session::has('log') && Session::get('log') == 0){
            return redirect('/')->with('alert','Anda Belum Login!');
        }

        $client = DB::table('users')
                ->select(DB::raw('count(*) as jlh, jenis'))
                ->groupBy('jenis')
                ->get();

        return view('brand-create',compact('client'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $dataC = User::where('email', $request->email)->first();
        if($dataC){
            return redirect()->route('brand.create')->with('alert','Email Sudah Terdaftar!');
        }

        DB::transaction(function () use ($request) {
            $data = new Brand();
            $data->namaUsaha = $request->usaha;
            $data->namaPemilik = $request->name;
            $data->phone = $request->phone;
            $data->email = $request->email;
            $data->address = $request->address;
            $data->save();

            $table = new User();
            $table->email = $request->email;
            $table->password = Hash::make($request->password);
            $table->jenis = "brand";
            $table->save();
        });

        $data = Brand::where('email', $request->email)->get();
        $dataC = User::where('email', $request->email)->get();
        if($data && $dataC){
            return redirect()->route('brand.index')->with('alert-success','Berhasil Menambahkan Data!');
        }
        return redirect()->route('brand.index')->with('alert','Gagal Menambahkan Data!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $dataP = Brand::where('id', $id)->first();

        DB::table('users')->where('email', $dataP->email)->delete();
        DB::table('brand')->where('id', $id)->delete();

        $data = Brand::where('id', $id)->get();
        if($data){
            return redirect()->route('brand.index')->with('alert-success','Berhasil Menghapus Data!');
        }
        return redirect()->route('brand.index')->with('alert','Gagal Menghapus Data!');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
