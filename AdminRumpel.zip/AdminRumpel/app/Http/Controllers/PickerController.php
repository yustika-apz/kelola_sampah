<?php

namespace App\Http\Controllers;

use App\User;
use App\Picker;
use App\Lapak;
use App\Sales;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class PickerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Session::has('log') && Session::get('log') == 0){
            return redirect('/')->with('alert','Anda Belum Login!');
        }

        if(Session::get('name') == "Admin"){
            $data = DB::table('picker')
            ->join('lapak', 'id_lapak', '=', 'lapak.id')
            ->select('lapak.namaUsaha',
                    'picker.*')
            ->get();
        } else {
            $data = Picker::where('id_lapak', Session::get('id'))->get();
        }
        return view('lapak.picker',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(!Session::has('log') && Session::get('log') == 0){
            return redirect('/')->with('alert','Anda Belum Login!');
        }

        return view('lapak.picker-create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request) {
        $dataC = User::where('email', $request->email)->first();
        if($dataC)
            return redirect()->route('picker.create')->with('alert','Email Sudah Terdaftar!');

        DB::transaction(function () use ($request) {
            $data = new Picker();
            $data->id_lapak = Session::get('id');
            $data->name = $request->name;
            $data->phone = $request->phone;
            $data->email = $request->email;
            $data->address = $request->address;
            $data->save();
    
            $table = new User();
            $table->email = $request->email;
            $table->password = Hash::make($request->password);
            $table->jenis = "picker";
            $table->save();
    
            $dataP = Lapak::where('id', Session::get('id'))->first();
            $dataP->jlhPemulung++;
            $dataP->save();
        });

        $data = Picker::where('email', $request->email)->get();
        $dataC = User::where('email', $request->email)->get();
        if($data && $dataC){
            return redirect()->route('picker.index')->with('alert-success','Berhasil Menambahkan Data!');
        }
        return redirect()->route('picker.index')->with('alert','Gagal Menambahkan Data!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $chart = Sales::selectRaw('SUM(beratTotal) AS total, MONTH(updateddate) AS month')
            ->groupby('month', 'id_picker')
            ->where('id_picker', $id)
            ->get();
        
        $picker = Picker::where('id', $id)->get();

        $data['chart'] = $chart;
        $data['picker'] = $picker;

        return view('lapak.picker-view',compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
