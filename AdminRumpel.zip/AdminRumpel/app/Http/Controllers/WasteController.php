<?php

namespace App\Http\Controllers;

use App\User;
use App\Waste;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class WasteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $waste = Waste::where('id_lapak', Session::get('id'))->get();

        $total = DB::table('brand_waste')
            ->select('jenis',
                    DB::raw('SUM(total) as total'))
            ->groupBy('jenis')
            ->where('id_lapak', Session::get('id'))
            ->get();
        
        if (Session::get('name') == "Admin") {
            $waste = DB::table('brand_waste')
                ->join('lapak', 'brand_waste.id_lapak', 'lapak.id')
                ->select('brand_waste.merk',
                    'brand_waste.jenis',
                    'brand_waste.total',
                    'lapak.namaUsaha')
            ->get();

            $total = DB::table('brand_waste')
                ->select('jenis',
                    DB::raw('SUM(total) as total'))
                ->groupBy('jenis')
                ->get();
        }

        $data['waste'] = $waste;
        $data['total'] = $total;
        return view('lapak.waste', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = new Waste();
        $data->id_lapak = Session::get('id');
        $data->jenis = $request->jenis;
        $data->merk = $request->merk;
        $data->total = $request->total;
        $data->save();

        return redirect('/waste')->with('alert-success', 'Data Berhasil Disimpan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $waste = Waste::where('id_lapak', Session::get('id'))->get();

        $total = DB::table('brand_waste')
            ->select('jenis',
                    DB::raw('SUM(total) as total'))
            ->groupBy('jenis')
            ->where('id_lapak', Session::get('id'))
            ->get();

        $update = Waste::where('id', $id)->get();

        $data['waste'] = $waste;
        $data['total'] = $total;
        $data['update'] = $update;
        return view('lapak.waste-edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function change(Request $request, $id)
    {
        $data = Waste::where('id', $id)->first();
        $data->total = $request->total;
        $data->save();

        return redirect('/waste');
    }
}
