<?php

namespace App\Http\Controllers;

use App\Client;
use App\Sales;
use App\SalesDet;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class POController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::table('sales')
            ->join('client', 'sales.id_client', '=', 'client.id')
            ->select('sales.*', 'client.name')
            ->where([
                    ['sales.status', 0],
                    ['client.id_lapak', Session::get('id')],
                    ['sales.isactivated', 1],
                    ['sales.id_picker', 0],
                    ])
            ->get();
        
        return view('lapak.pickup',['data' => $data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = DB::table('sales')
            ->join('client', 'sales.id_client', '=', 'client.id')
            ->select('sales.*', 'client.name')
            ->where([
                    ['sales.status', 1],
                    ['client.id_lapak', Session::get('id')],
                    ])
            ->get();
        
        if (Session::get('name') == "Admin") {
            $data = DB::table('sales')
                ->join('client', 'sales.id_client', '=', 'client.id')
                ->join('lapak', 'client.id_lapak', 'lapak.id')
                ->select('sales.*', 'client.name', 'lapak.namaUsaha')
                ->where([
                        ['sales.status', 1],
                        ])
                ->get();
        }

        return view('lapak.pickup-report',['data' => $data]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $dataD = Sales::where('id', $id)->first();
        
        if ($dataD->id_picker != 0) {
            $data = DB::table('sales')
                ->join('client', 'sales.id_client', '=', 'client.id')
                ->join('picker', 'sales.id_picker', '=', 'picker.id')
                ->join('salesdet', 'sales.id', '=', 'salesdet.id_sales')
                ->select('sales.*', 'client.name', 'picker.name as namaPicker', 'salesdet.*')
                ->where([
                    ['sales.id', $id],
                    ])
                ->get();
        } else {
            $data = DB::table('sales')
                ->join('client', 'sales.id_client', '=', 'client.id')
                ->join('salesdet', 'sales.id', '=', 'salesdet.id_sales')
                ->select('sales.*', 'client.name', 'salesdet.*')
                ->where([
                    ['sales.id', $id],
                    ])
                ->get();
        }

        return view('lapak.pickup-detail',['data' => $data]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $dataD = Sales::where('id', $id)->first();
        $dataD->status = 1;
        $dataD->save();

        return redirect('/pickup');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
