<?php

namespace App\Http\Controllers;

use App\User;
use App\Factory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class FactoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!Session::has('log') && Session::get('log') == 0){
            return redirect('/')->with('alert','Anda Belum Login!');
        }

        $data = Factory::all();
        return view('factory',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(!Session::has('log') && Session::get('log') == 0){
            return redirect('/')->with('alert','Anda Belum Login!');
        }

        $client = DB::table('users')
                ->select(DB::raw('count(*) as jlh, jenis'))
                ->groupBy('jenis')
                ->get();

        return view('factory-create',compact('client'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $dataC = User::where('email', $request->email)->first();
        if($dataC){
            return redirect()->route('factory.create')->with('alert','Email Sudah Terdaftar!');
        }

        DB::transaction(function () use ($request) {
            $data = new Factory();
            $data->namaUsaha = $request->usaha;
            $data->namaPemilik = $request->name;
            $data->phone = $request->phone;
            $data->email = $request->email;
            $data->address = $request->address;
            $data->save();
    
            $table = new User();
            $table->email = $request->email;
            $table->password = Hash::make($request->password);
            $table->jenis = "factory";
            $table->save();
        });

        $data = Factory::where('email', $request->email)->get();
        $dataC = User::where('email', $request->email)->get();
        if($data && $dataC){
            return redirect()->route('factory.index')->with('alert-success','Berhasil Menambahkan Data!');
        }
        return redirect()->route('factory.index')->with('alert-success','Gagal Menambahkan Data!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $dataP = Factory::where('id', $id)->first();

        DB::table('users')->where('email', $dataP->email)->delete();
        DB::table('factory')->where('id', $id)->delete();

        $data = Factory::where('id', $id)->get();
        if($data){
            return redirect()->route('brand.index')->with('alert-success','Berhasil Menghapus Data!');
        }
        return redirect()->route('brand.index')->with('alert','Gagal Menghapus Data!');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
