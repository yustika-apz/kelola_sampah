<?php

namespace App\Http\Controllers;

use App\User;
use App\Lapak;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function index(){
        if(Session::has('log') && Session::get('log') == 1){
            return view('index');
        }else{
            return view('login');
        }
    }

    public function login(Request $request){
        if($request->email == "admin@gmail.com" && $request->password == "admin123"){
            Session::put('log', 1);
            Session::put('name', "Admin");
            return redirect('/home');
        }else{
            $dataP = User::where('email', $request->email)->first();
            if($dataP && $dataP->jenis != "client" && Hash::check($request->password, $dataP->password)){
                $data = Lapak::where('email', $request->email)->first();
                Session::put('log', 1);
                Session::put('role', $dataP->jenis);
                Session::put('name', $data->namaUsaha);
                Session::put('id', $data->id);
                return redirect('/home');
            } else {
                return redirect('/')->with('alert','Password atau email salah!');
            }
        }
        return redirect('/')->with('alert','Anda Belum Login!');
    }
    
    public function logout(){
        Session::put('log', 0);
        Session::forget('log');
        Session::forget('name');
        Session::forget('id');
        Session::forget('role');
        return redirect('/');
    }
}
