<?php

namespace App\Http\Controllers;

use App\Client;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class ClientController extends Controller
{
    public function index()
    {
        if(!Session::has('log') && Session::get('log') == 0){
            return redirect('/')->with('alert','Anda Belum Login!');
        }

        if(Session::get('name') == "Admin"){
            $data = Client::all();
        } else {
            $data = Client::where('id_lapak', Session::get('id'))->get();
        }
        return view('client',compact('data'));
    }
}
