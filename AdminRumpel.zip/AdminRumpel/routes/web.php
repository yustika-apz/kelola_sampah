<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/home', function () {
//     return view('index');
// });

// Route::get('/', function () {
//     return view('login');
// });

Route::get('/chart', function () {
    return view('charts');
});

Route::get('/', 'UserController@index');
Route::get('/home', 'UserController@index');
Route::post('/login', 'UserController@login');
Route::get('/logout', 'UserController@logout');

Route::get('/client', 'ClientController@index');

Route::resource('lapak','LapakController');
Route::resource('factory','FactoryController');
Route::resource('brand','BrandController');
Route::resource('picker','PickerController');
Route::resource('pickup','POController');
Route::resource('waste','WasteController');

Route::post('/waste/update/{id}', 'WasteController@change');
