
<?php $__env->startSection('title', 'Rumah Pemulung'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
          
        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <!-- Begin Page Content -->
          <div class="container-fluid">
  
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Registrasi</h1>
            </div>
  
            <!-- Content Row -->
            <div class="row">
  
              <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akuns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-xl-3 col-md-6 mb-4">
                <?php if($akuns->jenis == "client"): ?>
                <div class="card border-left-primary shadow h-100 py-2">
                <?php elseif($akuns->jenis == "lapak"): ?>
                <div class="card border-left-success shadow h-100 py-2">
                <?php elseif($akuns->jenis == "factory"): ?>
                <div class="card border-left-info shadow h-100 py-2">
                <?php else: ?>
                <div class="card border-left-warning shadow h-100 py-2">
                <?php endif; ?>
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Akun <?php echo e($akuns->jenis); ?></div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($akuns->jlh); ?></div>
                      </div>
                      <div class="col-auto">
                      <?php if($akuns->jenis == "client"): ?>
                      <i class="fas fa-calendar fa-2x text-gray-300"></i>
                      <?php elseif($akuns->jenis == "lapak"): ?>
                      <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                      <?php elseif($akuns->jenis == "factory"): ?>
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                      <?php else: ?>
                      <i class="fas fa-comments fa-2x text-gray-300"></i>
                      <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
  
            <!-- Content Row -->
  
            <div class="row">  
              <div class="col-lg-12 mb-4">
    
                <!-- Approach -->
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Registrasi Brand</h6>
                  </div>

                  <?php if(\Session::has('alert')): ?>
                  <div class="alert alert-danger">
                    <div><?php echo e(Session::get('alert')); ?></div>
                      </div>
                  <?php endif; ?>
                  <?php if(\Session::has('alert-success')): ?>
                    <div class="alert alert-success">
                      <div><?php echo e(Session::get('alert-success')); ?></div>
                    </div>
                  <?php endif; ?>

                  <div class="card-body">
                    <form action="<?php echo e(route('brand.store')); ?>" method="post">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('POST')); ?>

                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="usaha" class="col-md-4 control-label"><b>Nama Usaha</b></label>
                                    <input type="text" class="form-control" id="usaha" name="usaha" required autofocus>
                                </div>

                                <div class="form-group">
                                    <label for="name" class="col-md-4 control-label"><b>Nama Pemilik</b></label>
                                    <input type="text" class="form-control" id="name" name="name" required autofocus>
                                </div>
                                    
                                <div class="form-group">
                                    <label for="address" class="col-md-4 control-label"><b>Alamat</b></label>
                                    <textarea rows="3" id="address" name="address" class="form-control" required autofocus></textarea>
                                </div>
                            </div>

                            <div class="col-md-6 border-left">
                                <div class="form-group">
                                    <label for="email" class="col-md-4 control-label"><b>Email Pemilik</b></label>
                                    <input type="text" class="form-control" id="email" name="email" required autofocus>
                                </div>

                                <div class="form-group">
                                    <label for="password" class="col-md-4 control-label"><b>Password</b></label>
                                    <input type="password" class="form-control" id="password" name="password" required autofocus>
                                </div>

                                <div class="form-group">
                                    <label for="phone" class="col-md-4 control-label"><b>Nomor HP Pemilik</b></label>
                                    <input type="text" class="form-control" id="phone" name="phone" maxlength="13"style="width: 13em" required autofocus> 
                                </div>
                            </div>

                            <div class="col-md-12">
                                <!-- <br> -->
                                <div class="submit-button text-right">
                                    <button type="reset" class="btn btn-md btn-warning">Cancel</button>
                                    <button type="submit" class="btn btn-md btn-primary">Simpan</button>
                                </div>
                            </div>
                        </div>
                    </form>
                  </div>
                </div>
  
              </div>
            </div>
  
          </div>
          <!-- /.container-fluid -->
  
        </div>
        <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Mata Kuliah\Semester 7\KP\AplysitCode\AdminRumpel\resources\views/brand-create.blade.php ENDPATH**/ ?>