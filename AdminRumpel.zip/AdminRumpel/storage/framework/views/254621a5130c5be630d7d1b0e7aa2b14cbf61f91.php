
<?php $__env->startSection('title', 'Rumah Pemulung'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Data Waste</h1>
            </div>

            <div class="row">

                <!-- Donut Chart -->
                <div class="col-lg-5 mb-4">
                    <div class="card shadow mb-4">
                        <!-- Card Header - Dropdown -->
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Merk Chart</h6>
                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <div class="chart-pie pt-2">
                                <canvas id="myPieChart"></canvas>
                            </div>
                            <hr>
                            Styling for the donut chart can be found in the
                        </div>
                    </div>
                </div>

                <!-- Content Column -->
                <div class="col-lg-7 mb-4">

                    <!-- Project Card Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Jenis</h6>
                        </div>
                        <div class="card-body">
                        <?php $__currentLoopData = $data['total']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h4 class="small font-weight-bold"><?php echo e($datas->jenis); ?> <span class="float-right"><?php echo e($datas->total); ?></span></h4>
                            <div class="progress mb-4">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo e($datas->total); ?>%"
                                    aria-valuenow="<?php echo e($datas->total); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            </div>

            <div class="row">
                <div class="col-lg-12 mb-4">

                    <?php if(\Session::has('alert')): ?>
                    <div class="alert alert-danger">
                        <div><?php echo e(Session::get('alert')); ?></div>
                    </div>
                    <?php endif; ?>
                    <?php if(\Session::has('alert-success')): ?>
                    <div class="alert alert-success">
                        <div><?php echo e(Session::get('alert-success')); ?></div>
                    </div>
                    <?php endif; ?>

                    <!-- Approach -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Add New Waste</h6>
                        </div>

                        <div class="card-body">
                            <?php $__currentLoopData = $data['update']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form action="<?php echo e(url('/waste/update/'. $datas->id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('POST')); ?>

                                <div class="row mt-4">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="merk" class="col-md-4 control-label"><b>Merk</b></label>
                                            <input type="text" class="form-control" value="<?php echo e($datas->merk); ?>"
                                                id="merk" name="merk" readonly>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col">
                                                    <label for="jenis" class="col-md-4 control-label"><b>Jenis</b></label>
                                                    <input type="text" class="form-control" id="jenis" name="jenis"
                                                        value="<?php echo e($datas->jenis); ?>" min="0" style="width: 15em" readonly>
                                                </div>

                                                <div class="col">
                                                    <label for="total"
                                                        class="col-md-4 control-label"><b>Total</b></label>
                                                        <input type="number" class="form-control" id="plastik" step="0.1"
                                                            name="plastik" value="<?php echo e($datas->total); ?>" min="0" style="width: 15em" required>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <br>
                                        <div class="submit-button text-right">
                                            <a href="<?php echo e(url('/waste')); ?>" class="btn btn-md btn-warning">Cancel</a>
                                            <button type="submit" class="btn btn-md btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Waste</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Merk</th>
                                            <th>Jenis</th>
                                            <th>Total (/kg)</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $no=1 ?>
                                        <?php $__currentLoopData = $data['waste']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($datas->merk); ?></td}>
                                            <td><?php echo e($datas->jenis); ?></td}>
                                            <td><?php echo e($datas->total); ?></td>
                                            <td>
                                                <a class="btn btn-info" href="<?php echo e(route('waste.edit', $datas->id)); ?>">Edit</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Mata Kuliah\Semester 7\KP\AplysitCode\AdminRumpel\resources\views/lapak/waste-edit.blade.php ENDPATH**/ ?>