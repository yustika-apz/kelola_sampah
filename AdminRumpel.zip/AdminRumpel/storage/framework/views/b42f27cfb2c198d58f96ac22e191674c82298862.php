
<?php $__env->startSection('title', 'Rumah Pemulung'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
          
        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Lapak</h1>
                  
            <?php if(\Session::has('alert')): ?>
            <div class="alert alert-danger">
              <div><?php echo e(Session::get('alert')); ?></div>
            </div>
            <?php endif; ?>
            <?php if(\Session::has('alert-success')): ?>
            <div class="alert alert-success">
              <div><?php echo e(Session::get('alert-success')); ?></div>
            </div>
            <?php endif; ?>
          
          <a href="<?php echo e(route('lapak.create')); ?>" class="btn btn-primary">+ Tambah Lapak</a>
          <br><br>
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Lapak</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Nama Usaha</th>
                      <th>Nama Pemilik</th>
                      <th>No. Telepon</th>
                      <th>Email</th>
                      <th>Alamat</th>
                      <th>Jumlah Pemulung</th>
                      <th>Jumlah plastik /bln</th>
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>
                  <?php $no=1 ?>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($no++); ?></td>
                      <td><?php echo e($datas->namaUsaha); ?></td}>
                      <td><?php echo e($datas->namaPemilik); ?></td>
                      <td><?php echo e($datas->phone); ?></td}>
                      <td><?php echo e($datas->email); ?></td}>
                      <td><?php echo e($datas->address); ?></td}>
                      <td><?php echo e($datas->jlhPemulung); ?></td}>
                      <td><?php echo e($datas->jlhPlastik); ?></td}>
                      <td>
                        <form method="GET" action="<?php echo e(route('lapak.edit', $datas->id)); ?>">
                          <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger btn-circle btn-sm" type="submit"
                            onclick="return confirm('Yakin ingin menghapus?')">
                            <i class="fas fa-trash" style="color:white"></i></button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Mata Kuliah\KP\AplysitCode\AdminRumpel\resources\views/lapak.blade.php ENDPATH**/ ?>