
<?php $__env->startSection('title', 'Rumah Pemulung'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Data Waste</h1>
            </div>

            <div class="row">

                <!-- Donut Chart -->
                <div class="col-lg-5 mb-4">
                    <div class="card shadow mb-4">
                        <!-- Card Header - Dropdown -->
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Merk Chart</h6>
                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <div class="chart-pie pt-2">
                                <canvas id="myPieChart"></canvas>
                            </div>
                            <hr>
                            Styling for the donut chart can be found in the
                        </div>
                    </div>
                </div>

                <!-- Content Column -->
                <div class="col-lg-7 mb-4">

                    <!-- Project Card Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Jenis</h6>
                        </div>
                        <div class="card-body">
                        <?php $__currentLoopData = $data['total']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h4 class="small font-weight-bold"><?php echo e($datas->jenis); ?> <span class="float-right"><?php echo e($datas->total); ?></span></h4>
                            <div class="progress mb-4">
                                <div class="progress-bar bg-danger" role="progressbar" style="width: <?php echo e($datas->total); ?>%"
                                    aria-valuenow="<?php echo e($datas->total); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                </div>
            </div>

            <div class="row">
                <div class="col-lg-12 mb-4">

                    <?php if(\Session::has('alert')): ?>
                    <div class="alert alert-danger">
                        <div><?php echo e(Session::get('alert')); ?></div>
                    </div>
                    <?php endif; ?>
                    <?php if(\Session::has('alert-success')): ?>
                    <div class="alert alert-success">
                        <div><?php echo e(Session::get('alert-success')); ?></div>
                    </div>
                    <?php endif; ?>

                    <?php if(Session::get('role') == "lapak"): ?>
                    <!-- Approach -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Add New Waste</h6>
                        </div>

                        <div class="card-body">
                            <form action="<?php echo e(route('waste.store')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('POST')); ?>

                                <div class="row mt-4">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="merk" class="col-md-4 control-label"><b>Merk</b></label>
                                            <input type="text" class="form-control" id="merk" name="merk" required
                                                autofocus>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col">
                                                    <label for="jenis"
                                                        class="col-md-4 control-label"><b>Jenis</b></label>
                                                    <select name="jenis" class="form-control" style="width: 15em">
                                                        <option value="HDPE" selected>HDPE</option>
                                                        <option value="LDPE">LDPE</option>
                                                        <option value="PET">PET</option>
                                                        <option value="PP">PP</option>
                                                        <option value="PS">PS</option>
                                                        <option value="PVC">PVC</option>
                                                        <option value="Other">Other</option>
                                                    </select>
                                                </div>

                                                <div class="col">
                                                    <label for="total"
                                                        class="col-md-4 control-label"><b>Total</b></label>
                                                    <input type="number" class="form-control" id="total" name="total"
                                                        min="0" style="width: 15em" required autofocus>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <br>
                                        <div class="submit-button text-right">
                                            <button type="reset" class="btn btn-md btn-warning">Cancel</button>
                                            <button type="submit" class="btn btn-md btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Waste</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Merk</th>
                                            <?php if(Session::get('name') == "Admin"): ?>
                                            <th>Nama Lapak</th>
                                            <?php endif; ?>
                                            <th>Jenis</th>
                                            <th>Total (/kg)</th>
                                            <?php if(Session::get('role') == "lapak"): ?>
                                            <th>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $no=1 ?>
                                        <?php $__currentLoopData = $data['waste']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($no++); ?></td>
                                            <td><?php echo e($datas->merk); ?></td}>
                                            <?php if(Session::get('name') == "Admin"): ?>
                                            <td><?php echo e($datas->namaUsaha); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($datas->jenis); ?></td}>
                                            <td><?php echo e($datas->total); ?></td>
                                            <?php if(Session::get('role') == "lapak"): ?>
                                            <td>
                                                <a class="btn btn-info" href="<?php echo e(route('waste.edit', $datas->id)); ?>">Edit</a>
                                            </td>
                                            <?php endif; ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Mata Kuliah\Semester 7\KP\AplysitCode\AdminRumpel\resources\views/lapak/waste.blade.php ENDPATH**/ ?>