
<?php $__env->startSection('title', 'Rumah Pemulung'); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Pickup Detail</h1>
            </div>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col-lg-12 mb-4">

                    <!-- Approach -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"><?php echo e($datas->name); ?> Request</h6>
                        </div>

                        <?php if(\Session::has('alert')): ?>
                        <div class="alert alert-danger">
                            <div><?php echo e(Session::get('alert')); ?></div>
                        </div>
                        <?php endif; ?>
                        <?php if(\Session::has('alert-success')): ?>
                        <div class="alert alert-success">
                            <div><?php echo e(Session::get('alert-success')); ?></div>
                        </div>
                        <?php endif; ?>

                        <div class="card-body">
                            <form action="<?php echo e(route('pickup.edit', $datas->id)); ?>" method="get">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('GET')); ?>

                                <div class="row mt-4">
                                    <div class="col-md-6">
                                        <div class="form-group text-center">
                                            <h4>Informasi Penjemputan</h4>
                                        </div>

                                        <div class="form-group">
                                            <div class="radio-toolbar">
                                                <?php if($datas->jenis == "Jual"): ?>
                                                <input type="radio" id="jual" name="jenis" value="Jual" checked>
                                                <label for="jual">Jual</label>
                                                <?php else: ?>
                                                <input type="radio" id="donasi" name="jenis" value="Donasi" checked>
                                                <label for="donasi">Donasi</label>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col">
                                                    <input class="form-control" type="text" name="tanggal"
                                                        placeholder="<?php echo e($datas->tanggal); ?>" style="width: 15em" readonly>
                                                </div>
                                                <div class="col">
                                                    <input class="form-control" type="text" name="waktu"
                                                        placeholder="<?php echo e($datas->jam); ?>.<?php echo e($datas->menit); ?> WIB" style="width: 15em" readonly>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <textarea rows="3" id="keterangan" name="keterangan" class="form-control"
                                                placeholder="<?php echo e($datas->location); ?>" readonly></textarea>
                                        </div>

                                        <div class="form-group">
                                            <textarea rows="3" id="keterangan" name="keterangan" class="form-control"
                                                placeholder="<?php echo e($datas->keterangan); ?>" readonly></textarea>
                                        </div>

                                    </div>

                                    <div class="col-md-6 border-left">
                                        <div class="form-group text-center">
                                            <h4>Detail Request</h4>
                                        </div>

                                        <div class="form-group text-center">
                                            <img width="50%" src="<?php echo e(url('img/sales/'.$datas->foto)); ?>">
                                        </div>

                                        <br>
                                        <div class="form-group">
            								<?php if($datas->beratBesi != 0): ?>
                                            <div class="row">
                                                <div class="col">Besi</div>
                                                <div class="col"><?php echo e($datas->beratBesi); ?> kg x Rp 2000</div>
                                            </div>
                                            <?php endif; ?>
            								<?php if($datas->beratKertas != 0): ?>
                                            <div class="row">
                                                <div class="col">Kertas</div>
                                                <div class="col"><?php echo e($datas->beratKertas); ?> kg x Rp 2000</div>
                                            </div>
                                            <?php endif; ?>
            								<?php if($datas->beratPlastik != 0): ?>
                                            <div class="row">
                                                <div class="col">Plastik</div>
                                                <div class="col"><?php echo e($datas->beratPlastik); ?> kg x Rp 2000</div>
                                            </div>
                                            <?php endif; ?>
                                            <hr>
                                            <div class="row">
                                                <div class="col"><b>TOTAL</b></div>
                                                <div class="col">Rp <?php echo e((2000* $datas->beratPlastik) + (2000* $datas->beratKertas) + (2000* $datas->beratBesi)); ?></div>
                                            </div>
                                        </div>
                                        <br>

                                        <?php if($datas->status != 0): ?>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col">Dijemput Oleh:</div>
                                                <div class="col">
                                                    <input class="form-control" type="text" name="waktu"
                                                        placeholder="<?php echo e($datas->namaPicker); ?>" style="width: 15em" readonly>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <div class="submit-button text-right">
                                        <?php if($datas->status == 0): ?>
                                            <a href="/pickup" class="btn btn-md btn-warning">Back</a>
                                            <button type="submit" class="btn btn-md btn-primary">Pick</button>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('pickup.create')); ?>" class="btn btn-md btn-warning">Back</a>
                                        <?php endif; ?>
                                        </div>

                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Mata Kuliah\Semester 7\KP\AplysitCode\AdminRumpel\resources\views/lapak/pickup-detail.blade.php ENDPATH**/ ?>