@extends('layouts.main')
@section('title', 'Rumah Pemulung')

@section('content')
<!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
          
        @include('layouts.topbar')

          <!-- Begin Page Content -->
          <div class="container-fluid">
  
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Registrasi</h1>
            </div>
  
            <!-- Content Row -->
            <div class="row">
  
              @foreach($client as $akuns)
              <div class="col-xl-3 col-md-6 mb-4">
                @if ($akuns->jenis == "client")
                <div class="card border-left-primary shadow h-100 py-2">
                @elseif ($akuns->jenis == "lapak")
                <div class="card border-left-success shadow h-100 py-2">
                @elseif ($akuns->jenis == "factory")
                <div class="card border-left-info shadow h-100 py-2">
                @else
                <div class="card border-left-warning shadow h-100 py-2">
                @endif
                  <div class="card-body">
                    <div class="row no-gutters align-items-center">
                      <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Akun {{ $akuns->jenis }}</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">{{ $akuns->jlh }}</div>
                      </div>
                      <div class="col-auto">
                      @if ($akuns->jenis == "client")
                      <i class="fas fa-calendar fa-2x text-gray-300"></i>
                      @elseif ($akuns->jenis == "lapak")
                      <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                      @elseif ($akuns->jenis == "factory")
                      <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                      @else
                      <i class="fas fa-comments fa-2x text-gray-300"></i>
                      @endif
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              @endforeach

            </div>
  
            <!-- Content Row -->
  
            <div class="row">  
              <div class="col-lg-12 mb-4">
    
                <!-- Approach -->
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Registrasi Brand</h6>
                  </div>

                  @if(\Session::has('alert'))
                  <div class="alert alert-danger">
                    <div>{{Session::get('alert')}}</div>
                      </div>
                  @endif
                  @if(\Session::has('alert-success'))
                    <div class="alert alert-success">
                      <div>{{Session::get('alert-success')}}</div>
                    </div>
                  @endif

                  <div class="card-body">
                    <form action="{{ route('brand.store') }}" method="post">
                      {{ csrf_field() }}
                      {{ method_field('POST') }}
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="usaha" class="col-md-4 control-label"><b>Nama Usaha</b></label>
                                    <input type="text" class="form-control" id="usaha" name="usaha" required autofocus>
                                </div>

                                <div class="form-group">
                                    <label for="name" class="col-md-4 control-label"><b>Nama Pemilik</b></label>
                                    <input type="text" class="form-control" id="name" name="name" required autofocus>
                                </div>
                                    
                                <div class="form-group">
                                    <label for="address" class="col-md-4 control-label"><b>Alamat</b></label>
                                    <textarea rows="3" id="address" name="address" class="form-control" required autofocus></textarea>
                                </div>
                            </div>

                            <div class="col-md-6 border-left">
                                <div class="form-group">
                                    <label for="email" class="col-md-4 control-label"><b>Email Pemilik</b></label>
                                    <input type="text" class="form-control" id="email" name="email" required autofocus>
                                </div>

                                <div class="form-group">
                                    <label for="password" class="col-md-4 control-label"><b>Password</b></label>
                                    <input type="password" class="form-control" id="password" name="password" required autofocus>
                                </div>

                                <div class="form-group">
                                    <label for="phone" class="col-md-4 control-label"><b>Nomor HP Pemilik</b></label>
                                    <input type="text" class="form-control" id="phone" name="phone" maxlength="13"style="width: 13em" required autofocus> 
                                </div>
                            </div>

                            <div class="col-md-12">
                                <!-- <br> -->
                                <div class="submit-button text-right">
                                    <button type="reset" class="btn btn-md btn-warning">Cancel</button>
                                    <button type="submit" class="btn btn-md btn-primary">Simpan</button>
                                </div>
                            </div>
                        </div>
                    </form>
                  </div>
                </div>
  
              </div>
            </div>
  
          </div>
          <!-- /.container-fluid -->
  
        </div>
        <!-- End of Main Content -->
@endsection