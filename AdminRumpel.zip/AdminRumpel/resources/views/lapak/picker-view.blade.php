@extends('layouts.main')
@section('title', 'Rumah Pemulung')

@section('content')
<!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
          
        @include('layouts.topbar')

          <!-- Begin Page Content -->
          <div class="container-fluid">
  
            <!-- Page Heading -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Detail</h1>
            </div>
  
            <div class="row">  
              <div class="col-lg-12 mb-4">
    
              <!-- Area Chart -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Area Chart</h6>
                </div>
                <div class="card-body">
                  <div class="chart-area">
                    <canvas id="myAreaChart"></canvas>
                  </div>
                  <hr>
                  Styling for the area chart can be found in the <code>/js/demo/chart-area-demo.js</code> file.
                </div>
              </div>

                <!-- Approach -->
                <div class="card shadow mb-4">
                  <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Detail Picker</h6>
                  </div>
                  
                  <div class="card-body">
                  @foreach ($data['picker'] as $datas)
                    <form action="{{ route('picker.index') }}" method="post">
                      {{ csrf_field() }}
                      {{ method_field('POST') }}
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="name" class="col-md-4 control-label"><b>Nama</b></label>
                                    <input type="text" class="form-control" id="name" name="name" value="{{ $datas->name }}" readonly>
                                </div>

                                <div class="form-group">
                                    <label for="address" class="col-md-4 control-label"><b>Alamat</b></label>
                                    <textarea rows="3" id="address" name="address" class="form-control" readonly>{{ $datas->address }}</textarea>
                                </div>
                            </div>

                            <div class="col-md-6 border-left">
                                <div class="form-group">
                                    <label for="email" class="col-md-4 control-label"><b>Email</b></label>
                                    <input type="text" class="form-control" id="email" name="email" value="{{ $datas->email }}" readonly>
                                </div>

                                <div class="form-group">
                                    <label for="phone" class="col-md-4 control-label"><b>Nomor HP</b></label>
                                    <input type="tel" class="form-control" id="phone" name="phone" value="{{ $datas->phone }}" maxlength="13" style="width: 13em" readonly> 
                                </div>
                            </div>

                            <div class="col-md-12">
                                <!-- <br> -->
                                <div class="submit-button text-right">
                                    <button type="submit" class="btn btn-md btn-primary">Back</button>
                                </div>
                            </div>
                        </div>
                    </form>
                  @endforeach
                  </div>
                </div>
  
              </div>
            </div>
  
          </div>
          <!-- /.container-fluid -->
  
        </div>
        <!-- End of Main Content -->
@endsection