@extends('layouts.main')
@section('title', 'Rumah Pemulung')

@section('content')
<!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">
          
        @include('layouts.topbar')

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-2 text-gray-800">Picker</h1>
                  
            @if(\Session::has('alert'))
            <div class="alert alert-danger">
              <div>{{Session::get('alert')}}</div>
            </div>
            @endif
            @if(\Session::has('alert-success'))
            <div class="alert alert-success">
              <div>{{Session::get('alert-success')}}</div>
            </div>
            @endif
          
          @if (Session::get('name') != "Admin")
          <a href="{{ route('picker.create') }}" class="btn btn-primary">+ Tambah Picker</a>
          <br><br>
          @endif
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Picker</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>Nama</th>
                      @if (Session::get('name') == "Admin")
                      <th>Nama Lapak</th>
                      @endif
                      <th>No. Telepon</th>
                      <th>Email</th>
                      <th>Alamat</th>
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>
                  @php $no=1 @endphp
                  @foreach($data as $datas)
                    <tr>
                      <td>{{ $no++ }}</td>
                      <td>{{ $datas->name }}</td}>
                      @if (Session::get('name') == "Admin")
                      <td>{{ $datas->namaUsaha }}</td>
                      @endif
                      <td>{{ $datas->phone }}</td>
                      <td>{{ $datas->email }}</td>
                      <td>{{ $datas->address }}</td>
                      <td>
                        <form method="GET" action="{{ route('picker.edit', $datas->id) }}">
                          {{ csrf_field() }}
                            <button class="btn btn-danger btn-circle btn-sm" type="submit"
                            onclick="return confirm('Yakin ingin menghapus?')">
                            <i class="fas fa-trash" style="color:white"></i></button>
                            <a href="{{ route('picker.show', $datas->id) }}" class="btn btn-info btn-circle btn-sm"><i class="fas fa-info"></i></a>
                        </form>
                      </td>
                    </tr>
                  @endforeach
                  </tbody>
                </table>
              </div>
            </div>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->
@endsection